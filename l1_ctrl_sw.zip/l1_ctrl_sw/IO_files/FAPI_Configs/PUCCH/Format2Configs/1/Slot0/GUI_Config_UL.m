Error: Invalid number of users
