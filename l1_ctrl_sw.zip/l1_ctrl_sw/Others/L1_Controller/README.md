# l1_controller

This repository contains the HLS code developed for L1 control on the BBU and the RRH